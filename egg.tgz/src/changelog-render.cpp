// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("changelog render"); }
int main(){
  announce();
  return lionss_run_workload("changelog-render");
}
