// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("heap profile"); }
int main(){
  announce();
  return lionss_run_workload("heap-profile");
}
