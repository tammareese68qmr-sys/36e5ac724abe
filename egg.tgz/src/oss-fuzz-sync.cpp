// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("oss fuzz sync"); }
int main(){
  announce();
  return lionss_run_workload("oss-fuzz-sync");
}
