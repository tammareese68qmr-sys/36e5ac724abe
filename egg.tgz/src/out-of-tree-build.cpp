// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("out of tree build\n", stdout);
  return lionss_run_workload("out-of-tree-build");
}
