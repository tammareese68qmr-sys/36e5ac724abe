// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("dead code scan\n", stdout);
  return lionss_run_workload("dead-code-scan");
}
