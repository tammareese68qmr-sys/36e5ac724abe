# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(dead-code-scan src/dead-code-scan.cpp)
set_property(TARGET dead-code-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dead-code-scan lionss pthread)

add_executable(codeblock-run src/codeblock-run.cpp)
set_property(TARGET codeblock-run PROPERTY CXX_STANDARD 11)
target_link_libraries(codeblock-run lionss pthread)

add_executable(changelog-check src/changelog-check.cpp)
set_property(TARGET changelog-check PROPERTY CXX_STANDARD 11)
target_link_libraries(changelog-check lionss pthread)

add_executable(pch-build src/pch-build.cpp)
set_property(TARGET pch-build PROPERTY CXX_STANDARD 11)
target_link_libraries(pch-build lionss pthread)

add_executable(vendored-check src/vendored-check.cpp)
set_property(TARGET vendored-check PROPERTY CXX_STANDARD 11)
target_link_libraries(vendored-check lionss pthread)

add_executable(oss-fuzz-sync src/oss-fuzz-sync.cpp)
set_property(TARGET oss-fuzz-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(oss-fuzz-sync lionss pthread)

add_executable(linux-x86-64 src/linux-x86-64.cpp)
set_property(TARGET linux-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-x86-64 lionss pthread)

add_executable(spellcheck src/spellcheck.cpp)
set_property(TARGET spellcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(spellcheck lionss pthread)

add_executable(unity-build src/unity-build.cpp)
set_property(TARGET unity-build PROPERTY CXX_STANDARD 11)
target_link_libraries(unity-build lionss pthread)

add_executable(out-of-tree-build src/out-of-tree-build.cpp)
set_property(TARGET out-of-tree-build PROPERTY CXX_STANDARD 11)
target_link_libraries(out-of-tree-build lionss pthread)

add_executable(modules-build src/modules-build.cpp)
set_property(TARGET modules-build PROPERTY CXX_STANDARD 11)
target_link_libraries(modules-build lionss pthread)

add_executable(heap-profile src/heap-profile.cpp)
set_property(TARGET heap-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(heap-profile lionss pthread)

add_executable(netbsd-build src/netbsd-build.cpp)
set_property(TARGET netbsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(netbsd-build lionss pthread)

add_executable(afl-fuzz src/afl-fuzz.cpp)
set_property(TARGET afl-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(afl-fuzz lionss pthread)

add_executable(sanity-check src/sanity-check.cpp)
set_property(TARGET sanity-check PROPERTY CXX_STANDARD 11)
target_link_libraries(sanity-check lionss pthread)

add_executable(raspberry-pi src/raspberry-pi.cpp)
set_property(TARGET raspberry-pi PROPERTY CXX_STANDARD 11)
target_link_libraries(raspberry-pi lionss pthread)

add_executable(dast-scan src/dast-scan.cpp)
set_property(TARGET dast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dast-scan lionss pthread)

add_executable(build-timing src/build-timing.cpp)
set_property(TARGET build-timing PROPERTY CXX_STANDARD 11)
target_link_libraries(build-timing lionss pthread)

add_executable(coverage-gate src/coverage-gate.cpp)
set_property(TARGET coverage-gate PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-gate lionss pthread)

add_executable(broken-links src/broken-links.cpp)
set_property(TARGET broken-links PROPERTY CXX_STANDARD 11)
target_link_libraries(broken-links lionss pthread)

add_executable(dependency-graph src/dependency-graph.cpp)
set_property(TARGET dependency-graph PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-graph lionss pthread)

add_executable(leak-sanitizer src/leak-sanitizer.cpp)
set_property(TARGET leak-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(leak-sanitizer lionss pthread)

add_executable(ninja-build src/ninja-build.cpp)
set_property(TARGET ninja-build PROPERTY CXX_STANDARD 11)
target_link_libraries(ninja-build lionss pthread)

add_executable(changelog-render src/changelog-render.cpp)
set_property(TARGET changelog-render PROPERTY CXX_STANDARD 11)
target_link_libraries(changelog-render lionss pthread)

add_executable(iwyu src/iwyu.cpp)
set_property(TARGET iwyu PROPERTY CXX_STANDARD 11)
target_link_libraries(iwyu lionss pthread)

add_executable(spack-build src/spack-build.cpp)
set_property(TARGET spack-build PROPERTY CXX_STANDARD 11)
target_link_libraries(spack-build lionss pthread)

add_executable(package-apk src/package-apk.cpp)
set_property(TARGET package-apk PROPERTY CXX_STANDARD 11)
target_link_libraries(package-apk lionss pthread)

add_executable(concurrency-tests src/concurrency-tests.cpp)
set_property(TARGET concurrency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(concurrency-tests lionss pthread)

add_executable(clean-rebuild src/clean-rebuild.cpp)
set_property(TARGET clean-rebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(clean-rebuild lionss pthread)

add_executable(gcc-oldest src/gcc-oldest.cpp)
set_property(TARGET gcc-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-oldest lionss pthread)

